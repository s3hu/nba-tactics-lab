import { Suspense } from "react";
import { CATEGORIES, getCategoryById } from "@/lib/data/categories";
import { getAllArticles, getFeaturedArticle } from "@/lib/api/articles";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { HeroSection } from "@/components/hero-section";
import { CategoryTabs } from "@/components/category-tabs";
import { ArticleGrid } from "@/components/article-grid";

type HomePageProps = {
  // Next.js 15/16 では searchParams は Promise で渡ってくる。
  // ここを await せずに分割代入すると、category/q が常に undefined になり
  // 「タブを押しても絞り込まれない」不具合の直接原因になる。
  searchParams: Promise<{
    category?: string;
    q?: string;
  }>;
};

export default async function HomePage({ searchParams }: HomePageProps) {
  const { category: activeCategoryId, q: query } = await searchParams;

  const [featured, articles] = await Promise.all([
    getFeaturedArticle(),
    getAllArticles({ categoryId: activeCategoryId, query }),
  ]);

  const showHero = !activeCategoryId && !query && featured;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      {/*
        SiteHeader / SearchBar は内部で useSearchParams() を使うクライアント
        コンポーネントのため、Next.js のルールに従い Suspense で囲む。
        こうしておかないとビルド時に
        "useSearchParams() should be wrapped in a suspense boundary" の
        警告・エラーが出ることがある。
      */}
      <Suspense fallback={<HeaderFallback />}>
        <SiteHeader categories={CATEGORIES} />
      </Suspense>

      <main className="mx-auto max-w-6xl px-4 py-8">
        {showHero && (
          <HeroSection article={featured} category={getCategoryById(featured.categoryId)} />
        )}

        <div className="mb-6 flex flex-col gap-4">
          <CategoryTabs
            categories={CATEGORIES}
            activeCategoryId={activeCategoryId}
            currentQuery={query}
          />

          {query && (
            <p className="text-sm text-slate-500">
              「<span className="text-orange-400">{query}</span>」の検索結果：{articles.length}件
            </p>
          )}

          {activeCategoryId && !query && (
            <p className="text-sm text-slate-500">
              カテゴリー「
              <span className="text-orange-400">
                {getCategoryById(activeCategoryId)?.label ?? activeCategoryId}
              </span>
              」の記事：{articles.length}件
            </p>
          )}
        </div>

        <ArticleGrid articles={articles} categories={CATEGORIES} />
      </main>

      <SiteFooter categories={CATEGORIES} />
    </div>
  );
}

/** SiteHeaderのSuspense中に表示する最低限のフォールバック（レイアウトシフト防止） */
function HeaderFallback() {
  return <div className="h-16 border-b border-slate-800 bg-slate-950/90" />;
}
