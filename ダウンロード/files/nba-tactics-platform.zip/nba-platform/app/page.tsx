import { CATEGORIES, getCategoryById } from "@/lib/data/categories";
import { getAllArticles, getFeaturedArticle } from "@/lib/api/articles";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { HeroSection } from "@/components/hero-section";
import { CategoryTabs } from "@/components/category-tabs";
import { ArticleGrid } from "@/components/article-grid";

type HomePageProps = {
  // Next.js 15以降ではsearchParamsがPromiseになるため、
  // その場合は `searchParams: Promise<{...}>` にして
  // `const { category, q } = await searchParams;` と読み替えること。
  searchParams: {
    category?: string;
    q?: string;
  };
};

export default async function HomePage({ searchParams }: HomePageProps) {
  const activeCategoryId = searchParams.category;
  const query = searchParams.q;

  const [featured, articles] = await Promise.all([
    getFeaturedArticle(),
    getAllArticles({ categoryId: activeCategoryId, query }),
  ]);

  const showHero = !activeCategoryId && !query && featured;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <SiteHeader categories={CATEGORIES} />

      <main className="mx-auto max-w-6xl px-4 py-8">
        {showHero && (
          <HeroSection article={featured} category={getCategoryById(featured.categoryId)} />
        )}

        <div className="mb-6 flex flex-col gap-4">
          <CategoryTabs
            categories={CATEGORIES}
            activeCategoryId={activeCategoryId}
            currentQuery={query}
          />

          {query && (
            <p className="text-sm text-slate-500">
              「<span className="text-orange-400">{query}</span>」の検索結果：{articles.length}件
            </p>
          )}
        </div>

        <ArticleGrid articles={articles} categories={CATEGORIES} />
      </main>

      <SiteFooter categories={CATEGORIES} />
    </div>
  );
}
